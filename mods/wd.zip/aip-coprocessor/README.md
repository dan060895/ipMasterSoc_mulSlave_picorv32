AIP Coprocessor hdl
