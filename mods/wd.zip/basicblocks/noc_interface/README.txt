Is important to define the NoC_interface and ctrl_interface files usage.

-First, copy this files into the src/
-Change the files name adding '_nameproject' (Ex. _ipdummy)
-Change the functionality to each file as required to the design
-Just add this files instead the originals in the design project

For more information see the documentation 'interface_v1.pdf'